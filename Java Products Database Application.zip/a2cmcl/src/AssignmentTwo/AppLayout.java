package AssignmentTwo;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.*;
import javax.swing.*;

public class AppLayout extends JFrame implements ActionListener
{
	private static LinkedList <Sale> salesList = new LinkedList <Sale>();
	HashMap <Integer, Product> productsList = new HashMap <Integer, Product>(50);
	Product productEdit = new Product();
	private int basketCount = 0, quantity = 0;
	private Double saleTotal = 0.0;
	File codeFile = new File ("itemCodes.txt");

	private Font menuFont = new Font("Consoloas", Font.BOLD, 18);
	private Font menuItemFont = new Font("Consoloas", Font.PLAIN, 14);
	private Font headingFont = new Font ("Consoloas", Font.ITALIC, 30);
	Container cPane;
	private JPanel pLeft, pMiddle, pRight;
	private static AppLayout gui;
	private JMenuBar menuBar;
	private JMenu menuProducts, menuStock, menuReports, menuSystem;
	private JMenuItem mIAdd, mIUpdate, mIDelete, mIDisplay, mIMakeSale, mILowStock, mIProductsByCat, mIAllSales, mIExit;
	private JLabel lblAddTitle, lblProdID,lblProdIDShow, lblProdName, lblProdSize, lblProdCat, lblPrice, lblProdCatShow, lblStockLevel, lblSearch, lblSpacer;
	private JLabel lblQuantity, lblSaleDate, lblCustName, lblSaleDateShow, lblSaleID, lblSaleIDShow, lblHeader;
	private JTextField txtfProdName, txtfProdPrice, txtfSearch, txtfStockLevel, txtfQuantity, txtfCustName;
	private JComboBox cmbProdSize, cmbCat, cmbItemName;
	private JTextArea taDisplay, taShowProducts;
	private JButton btnBeauty, btnFood, btnSportsNutrition, btnVitamins, btnWeightloss, btnAddProd, btnDeleteProd, btnResetProd, btnCancelProd, btnSalesRep, btnLowStockRep;
	private JButton btnBeautyRep, btnFoodRep, btnSportsRep, btnVitaminsRep, btnWeightLossRep;
	private JButton btnExitApp, btnEditProd, btnIDSearch, btnIDSearchDelete, btnAddItem, btnClearCart, btnMakeSale, btnCancelSale;
	private String headerText = "", addListText = "";
	private String displayHeadings = "";
	private String errorMessage = "                       ERROR - INVALID INPUT \n"
			  + "--------------------------------------------------------------------------------\n";;
	private JScrollPane scroll, prodDisplayScroll;
	
	private String currTime = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
	private String currDate = LocalDate.now().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));
	private String timeStamp = (currDate + " @ " + currTime);
	
	private Product[] basket = new Product[500];
	private String[] itemCodes = new String[500];
	private String[] sortProds;
	
	File productsFile = new File("Products.txt");
	File salesFile = new File("Sales.txt");
	
	public AppLayout()
	{
		gui = this;
		readProducts();
		readSales();
		handleFrmExitButton();
		createLayout();
		assignActionListeners();
		clearScreen();
	}
	private void createLayout() 
	{
		//fillProductsList();
		displayHeadings = String .format("   %-7s %-20s %-8s %-20s %-11s %-10s %-12s", "ID", "Name", "Size", "Category", "Unit Price", "In Stock", "Sold");
		displayHeadings +=  "\n -----------------------------------------------------------------------------------------";
		
		cPane = getContentPane();
		cPane.setBackground(new Color(80,80,80));
		cPane.setLayout(new GridBagLayout());
		
		// Creating 3 Panels //
		pLeft = new JPanel();
		pMiddle = new JPanel();
		pRight = new JPanel();
		
		
		// Layouts of Panels //
		pLeft.setLayout(new GridBagLayout());
		pLeft.setBackground(new Color(60,60,60));
		pMiddle.setLayout(new GridBagLayout());
		pMiddle.setBackground(new Color(60,60,60));
		pRight.setLayout(new GridBagLayout());
		pRight.setBackground(new Color(60,60,60));
		
		// Menu Bar + Menus initialisation //
		menuBar = new JMenuBar();
		menuProducts = new JMenu("Products");
		menuProducts.setIcon(new ImageIcon("productsIcon.png"));
		menuStock = new JMenu("Stock");
		menuStock.setIcon(new ImageIcon("menuStockIcon.png"));
		menuReports = new JMenu("Reports");
		menuReports.setIcon(new ImageIcon("menuReportIcon.png"));
		menuSystem = new JMenu("System");
		menuSystem.setIcon(new ImageIcon("menuSettingsIcon.png"));
		
		//Products Menu Items initialisation //
		mIAdd = new JMenuItem("Add Product");
		
		mIAdd.setIcon(new ImageIcon("addIcon.png"));
		mIUpdate = new JMenuItem("Update Product");
		mIUpdate.setIcon(new ImageIcon("updateIcon.png"));
		mIDelete = new JMenuItem("Delete Product");
		mIDelete.setIcon(new ImageIcon ("deleteIcon.png"));
		
		
		// Stock Menu Items initialisation //
		mIDisplay = new JMenuItem("Display Stock");
		mIDisplay.setIcon(new ImageIcon ("displayIcon.png"));
		mIMakeSale = new JMenuItem("Make Sale");
		mIMakeSale.setIcon(new ImageIcon ("saleIcon.png"));
		
		// Reports Menu Items initialisation //
		mILowStock = new JMenuItem("Low Stock Items");
		mILowStock.setIcon(new ImageIcon ("lowStockIcon.png"));
		mIProductsByCat = new JMenuItem("Products By Category");
		mIProductsByCat.setIcon(new ImageIcon ("catIcon.png"));
		mIAllSales = new JMenuItem("All Sales");
		mIAllSales.setIcon(new ImageIcon ("allSalesIcon.png"));
		
		// System Menu Items initialisation //
		mIExit = new JMenuItem("Exit");
		mIExit.setIcon(new ImageIcon ("exitIcon.png"));
		
		// Labels for Add Screen //
		lblAddTitle = new JLabel(headerText, JLabel.CENTER);
		lblAddTitle.setFont(menuFont);
		lblAddTitle.setForeground(Color.white);
		
		lblProdID = new JLabel("Product ID:", JLabel.CENTER);
		lblProdID.setFont(menuItemFont);;
		lblProdID.setForeground(Color.white);
		
		lblProdIDShow = new JLabel (""); 							
		lblProdIDShow.setFont(menuItemFont);
		lblProdIDShow.setForeground(Color.white);
		
		lblProdName = new JLabel("Name:", JLabel.CENTER);
		lblProdName.setFont(menuItemFont);
		lblProdName.setForeground(Color.white);
		
		lblProdSize = new JLabel("Size", JLabel.CENTER);
		lblProdSize.setFont(menuItemFont);
		lblProdSize.setForeground(Color.white);
		
		lblStockLevel = new JLabel("Stock Level", JLabel.CENTER);
		lblStockLevel.setFont(menuItemFont);
		lblStockLevel.setForeground(Color.white);
		
		lblProdCat = new JLabel("Category:", JLabel.CENTER);
		lblProdCat.setFont(menuItemFont);
		lblProdCat.setForeground(Color.white);
		
		lblPrice = new JLabel("Price:", JLabel.CENTER);
		lblPrice.setFont(menuItemFont);
		lblPrice.setForeground(Color.white);
		
		lblProdCatShow = new JLabel("");
		lblProdCatShow.setFont(menuItemFont);
		lblProdCatShow.setForeground(Color.white);

		lblSearch = new JLabel("Enter Product ID");
		lblSearch.setHorizontalAlignment(SwingConstants.CENTER);
		lblSearch.setFont(menuItemFont);
		lblSearch.setForeground(Color.white);
		
		lblSpacer = new JLabel(" ");
		lblSpacer.setFont(menuItemFont);
		lblSpacer.setForeground(Color.white);
		
		lblQuantity = new JLabel("Quantity:");
		lblQuantity.setFont(menuItemFont);
		lblQuantity.setForeground(Color.white);
		
		
		
		lblSaleDate	= new JLabel("Sale Date:");
		lblSaleDate.setFont(menuItemFont);
		lblSaleDate.setForeground(Color.white);
		
		lblSaleDateShow	= new JLabel("-");	
		lblSaleDateShow.setFont(menuItemFont);
		lblSaleDateShow.setForeground(Color.white);
		
		lblSaleID = new JLabel("Sale ID:");	
		lblSaleID.setFont(menuItemFont);
		lblSaleID.setForeground(Color.white);
		
		lblSaleIDShow = new JLabel("-");	
		lblSaleIDShow.setFont(menuItemFont);
		lblSaleIDShow.setForeground(Color.white);
		
		lblHeader = new JLabel("Add Product");	
		lblHeader.setHorizontalAlignment(SwingConstants.CENTER);
		lblHeader.setFont(headingFont);
		lblHeader.setForeground(Color.white);
		
		
		lblCustName	= new JLabel("Customer:");	
		lblCustName.setFont(menuItemFont);
		lblCustName.setForeground(Color.white);
		
		txtfCustName = new JTextField();	
		txtfSearch = new JTextField();
		txtfSearch.setHorizontalAlignment(SwingConstants.CENTER);
		
		txtfStockLevel = new JTextField();
		txtfQuantity = new JTextField();
		
		taDisplay = new JTextArea();
		taDisplay.setFont(new Font("Courier New", Font.BOLD, 16));
		
		taShowProducts = new JTextArea("");
		taShowProducts.setFont(new Font("Courier New", Font.BOLD, 16));
		
		scroll = new JScrollPane(taDisplay);
		prodDisplayScroll = new JScrollPane(taShowProducts);
		
		
		
		
		// Setting menu bar to form and adding menus to MenuBar //
		setJMenuBar(menuBar);
		menuBar.add(menuProducts);
		menuBar.add(menuStock);
		menuBar.add(menuReports);
		menuBar.add(menuSystem);
		
		// Adding menu items to menus //
		menuProducts.add(mIAdd);
		menuProducts.add(mIUpdate);
		menuProducts.add(mIDelete);
		
		menuStock.add(mIDisplay);
		menuStock.add(mIMakeSale);
		
		menuReports.add(mILowStock);
		menuReports.add(mIProductsByCat);
		menuReports.add(mIAllSales);
		
		menuSystem.add(mIExit);
		
		// Changing font of all Menus and MenuItems //
		menuBar.setFont(menuFont);
		menuProducts.setFont(menuFont);
		menuStock.setFont(menuFont);
		menuReports.setFont(menuFont);
		menuSystem.setFont(menuFont);
		
		mIAdd.setFont(menuItemFont);
		mIUpdate.setFont(menuItemFont);
		mIDelete.setFont(menuItemFont);
		mIDisplay.setFont(menuItemFont);
		mIMakeSale.setFont(menuItemFont);
		mILowStock.setFont(menuItemFont);
		mIProductsByCat.setFont(menuItemFont);
		mIAllSales.setFont(menuItemFont);
		mIExit.setFont(menuItemFont);
		
		// Main Interface Buttons //
		btnBeauty =  new JButton("Beauty");
		btnBeauty.setHorizontalAlignment(SwingConstants.CENTER);
		btnBeauty.setIcon(new ImageIcon("beautyIcon.png"));
		btnBeauty.setFont(menuFont);
		
		btnFood =  new JButton("Food");
		btnFood.setHorizontalAlignment(SwingConstants.CENTER);
		btnFood.setIcon(new ImageIcon("foodIcon.png"));
		btnFood.setFont(menuFont);
		
		
		btnSportsNutrition=  new JButton("Sports Nutrition");
		btnSportsNutrition.setHorizontalAlignment(SwingConstants.CENTER);
		btnSportsNutrition.setIcon(new ImageIcon("sportsIcon.png"));
		btnSportsNutrition.setFont(menuFont);
		
		
		btnVitamins =  new JButton("Vitamins");
		btnVitamins.setHorizontalAlignment(SwingConstants.CENTER);
		btnVitamins.setIcon(new ImageIcon("vitaminsIcon.png"));
		btnVitamins.setFont(menuFont);
		
		
		btnWeightloss =  new JButton("Weight Loss");
		btnWeightloss.setHorizontalAlignment(SwingConstants.CENTER);
		btnWeightloss.setIcon(new ImageIcon("weightLossIcon.png"));
		btnWeightloss.setFont(menuFont);
		
		// Add menu button //
		btnAddProd = new JButton("Add");
		btnAddProd.setFont(menuFont);
		btnEditProd = new JButton("Edit");
		btnEditProd.setFont(menuFont);
		btnResetProd = new JButton("Reset");
		btnResetProd.setFont(menuFont);
		btnCancelProd = new JButton("Cancel");
		btnCancelProd.setFont(menuFont);
		btnDeleteProd = new JButton("Delete");
		btnDeleteProd.setFont(menuFont);
		btnExitApp = new JButton("Exit");
		btnExitApp.setFont(menuFont);
		
		btnSalesRep = new JButton("Export Report");
		btnSalesRep.setFont(menuFont);
		
		btnLowStockRep = new JButton("Export Report");
		btnLowStockRep.setFont(menuFont);
		
		btnBeautyRep = new JButton("Export Report");
		btnBeautyRep.setFont(menuFont);
		btnBeautyRep.setHorizontalAlignment(SwingConstants.CENTER);
		btnBeautyRep.setIcon(new ImageIcon("beautyIcon.png"));

		btnFoodRep = new JButton("Export Report");
		btnFoodRep.setFont(menuFont);
		btnFoodRep.setHorizontalAlignment(SwingConstants.CENTER);
		btnFoodRep.setIcon(new ImageIcon("foodIcon.png"));
		
		btnSportsRep = new JButton("Export Report");
		btnSportsRep.setFont(menuFont);
		btnSportsRep.setHorizontalAlignment(SwingConstants.CENTER);
		btnSportsRep.setIcon(new ImageIcon("sportsIcon.png"));
		
		btnVitaminsRep = new JButton("Export Report");
		btnVitaminsRep.setFont(menuFont);
		btnVitaminsRep.setHorizontalAlignment(SwingConstants.CENTER);
		btnVitaminsRep.setIcon(new ImageIcon("vitaminsIcon.png"));
		
		btnWeightLossRep = new JButton("Export Report");
		btnWeightLossRep.setFont(menuFont);
		btnWeightLossRep.setHorizontalAlignment(SwingConstants.CENTER);
		btnWeightLossRep.setIcon(new ImageIcon("weightLossIcon.png"));
		
		
		btnIDSearch = new JButton("Search");
		btnIDSearch.setHorizontalAlignment(SwingConstants.CENTER);
		btnIDSearch.setFont(menuFont);
		btnIDSearch.setIcon(new ImageIcon("searchIcon.png"));
		
		btnIDSearchDelete = new JButton("Search");
		btnIDSearchDelete.setHorizontalAlignment(SwingConstants.CENTER);
		btnIDSearchDelete.setFont(menuFont);
		btnIDSearchDelete.setIcon(new ImageIcon("searchIcon.png"));
		
		btnAddItem = new JButton("Add Item");
		btnAddItem.setHorizontalAlignment(SwingConstants.CENTER);
		btnAddItem.setFont(menuFont);
		btnAddItem.setIcon(new ImageIcon("addItemIcon.png"));
		
		btnCancelSale = new JButton("Cancel Sale");
		btnCancelSale.setHorizontalAlignment(SwingConstants.CENTER);
		btnCancelSale.setFont(menuFont);
		btnCancelSale.setIcon(new ImageIcon("addItemIcon.png"));
		
		
		btnClearCart = new JButton("Clear Cart");
		btnClearCart.setHorizontalAlignment(SwingConstants.CENTER);
		btnClearCart.setFont(menuFont);
		btnClearCart.setIcon(new ImageIcon("addClearCartIcon.png"));
		
		btnMakeSale = new JButton("Make Sale");
		btnMakeSale.setHorizontalAlignment(SwingConstants.CENTER);
		btnMakeSale.setFont(menuFont);
		btnMakeSale.setIcon(new ImageIcon("makeSaleIcon.png"));
		
		
		txtfProdName = new JTextField();
		txtfProdPrice = new JTextField();
		cmbProdSize = new JComboBox(new String [] {"---SELECT---","S","M","L","XL","XXL"});
		cmbCat = new JComboBox(new String [] {"---Select---","Beauty", "Food", "Sports Nutrition", "Vitamins", "Weight Loss"});
		cmbCat.setFont(menuFont);
		cmbItemName = new JComboBox();
		cmbItemName.setFont(menuFont);
		
		taDisplay.setEnabled(false);
		taDisplay.setDisabledTextColor(Color.black);
		taShowProducts.setEnabled(false);
		taShowProducts.setDisabledTextColor(Color.black);

		addComponents();
	}
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
    {
		// Adds components to the gridbag layout// 
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        gc.fill=GridBagConstraints.BOTH;
        gc.gridx = gridx;
        gc.gridy = gridy;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = weightX;
        gc.weighty = weightY;

        con.add(c,gc);
    }
	private void addComp(Component c, int x, int y, int w, int h, int wX, int wY)
	{
		// Adds components to the gridbag layout// 
		GridBagConstraints gc = new GridBagConstraints();
		gc.gridx = x;
		gc.gridy = y;
		gc.gridwidth=w;
		gc.gridheight=h;
		gc.weightx=wX;
		gc.weighty=wY;
		gc.fill = GridBagConstraints.BOTH;
		gc.insets = new Insets(5,5,5,5);
		
		getContentPane().add(c, gc);
	}
	public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource() == mIAdd)
		{
			lblHeader.setText("Add Product");
			btnResetProd.setEnabled(true);
			txtfProdName.setEnabled(true);
			txtfStockLevel.setEnabled(true);
			txtfProdPrice.setEnabled(true);
			cmbProdSize.setEnabled(true);
			clearScreen();
			clearInput();
			showAddOptions();
		}
		if (e.getSource() == mIMakeSale)
		{
			String s = String.format("   %-9s %-20s %-9s %-11s %-9s", "ItemID", "Item Desc.", "Price", "Quantity", "Total");
			s += "\n----------------------------------------------------------------";
			
			
			cmbCat.setSelectedIndex(0);
			txtfQuantity.setText("");
			txtfCustName.setText("");
			txtfCustName.setEnabled(true);
			taShowProducts.setText(s);
			
			clearScreen();
			showSaleScreen();	
			
			taShowProducts.setText(s);
			LocalDate saleDate = LocalDate.now();
			lblSaleDateShow.setText(saleDate.toString());
			
			lblSaleIDShow.setText("" + (1000 + salesList.size()));			
		}
		if (e.getSource() == mILowStock)
		{
			clearScreen();
			pLeft.setVisible(true);
			scroll.setVisible(true);
			taDisplay.setVisible(true);
			displayLowStock();
			btnLowStockRep.setVisible(true);
			lblSpacer.setVisible(true);
			btnExitApp.setVisible(true);
			
		}
		if (e.getSource()== btnBeauty)
		{
			clearScreen();
			showAddBeauty();
			addListText = "\t\t\t   Existing Beauty Products\n\n";
			taShowProducts.setText(addListText);
			displayBeautyItems();
		}
		if (e.getSource()== btnFood)
		{
			clearScreen();
			showAddFood();
			addListText = "\t\t\t   Existing Food Products\n\n";
			taShowProducts.setText(addListText);
			displayFoodItems();
		}
		if (e.getSource()== btnSportsNutrition)
		{
			clearScreen();
			showAddSportsNutrition();
			addListText = "\t\t\t   Existing Sports Nutrition Products\n\n";
			taShowProducts.setText(addListText);
			displaySportsItems();
		}
		if (e.getSource()== btnVitamins)
		{
			clearScreen();
			showAddVitamin();
			addListText = "\t\t\t   Existing Vitamins Products\n\n";
			taShowProducts.setText(addListText);
			displayVitaminsItems();
		}
		if (e.getSource()== btnWeightloss)
		{
			clearScreen();
			showAddWeightLoss();
			addListText = "\t\t\t   Existing Weight Loss Products\n\n";
			taShowProducts.setText(addListText);
			displayWeightLossItems();
		}
		if (e.getSource() == btnAddProd)
		{
			if (validateProduct() == true)
			{
				if (validateSameName() == true)
				{
					JOptionPane.showMessageDialog(null, errorMessage + "This product has already been added to the system");
				}
				else
				{
					Product newP = new Product(Integer.parseInt(lblProdIDShow.getText()), txtfProdName.getText(),lblProdCatShow.getText(), cmbProdSize.getSelectedItem().toString(), Double.parseDouble(txtfProdPrice.getText()), Integer.parseInt(txtfStockLevel.getText()), 0);

					productsList.put(newP.getProductID(), newP);
					clearScreen();
					showAddOptions();
					clearInput();
					displayByCat();
					validateSameName();
				}
			}
			else
			{
				JOptionPane.showMessageDialog(null, errorMessage);
			}
		}
		if (e.getSource() == btnEditProd)
		{
			if (validateProduct() == true)
			{
				productEdit.setName(txtfProdName.getText());
				productEdit.setCategory(lblProdCatShow.getText());
				productEdit.setSize(cmbProdSize.getSelectedItem().toString());
				productEdit.setUnitPrice(Double.parseDouble(txtfProdPrice.getText()));
				productEdit.setStockLevel(Integer.parseInt(txtfStockLevel.getText()));
				
				int id = productEdit.getProductID();
				productsList.remove(id);
				productsList.put(id,productEdit);
				clearScreen();
				pLeft.setVisible(true);
				taDisplay.setVisible(true);
				scroll.setVisible(true);
				displayByCat();
			}
			else
			{
				JOptionPane.showMessageDialog(null, errorMessage);
			}
			
		}
		if (e.getSource() == btnResetProd)
		{
			clearInput();
		}
		if (e.getSource() == btnCancelProd)
		{
			clearInput();
			clearScreen();
			showAddOptions();
		}
		if (e.getSource() == btnCancelSale)
		{
			clearScreen();
		}
		if (e.getSource() == btnExitApp)
		{
			int input = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit the system?", "Exit System?",
					JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.ERROR_MESSAGE);
			if (input == 0)
			{

				writeProducts();
				writeSales();
				System.exit(0);
			}
		}
		if (e.getSource() == mIProductsByCat)
		{
			displayByCat();
			btnBeautyRep.setVisible(true);
			btnFoodRep.setVisible(true);
			btnSportsRep.setVisible(true);
			btnVitaminsRep.setVisible(true);
			btnWeightLossRep.setVisible(true);
		}
		if (e.getSource() == mIUpdate)
		{
			
			lblSearch.setText("Enter Product ID");
			btnResetProd.setEnabled(true);
			txtfProdName.setEnabled(true);
			txtfStockLevel.setEnabled(true);
			txtfProdPrice.setEnabled(true);
			cmbProdSize.setEnabled(true);
			clearScreen();
			showSearchScreen();
			lblHeader.setVisible(true);
			lblHeader.setText("Edit Product");
		}
		if (e.getSource() == mIDelete)
		{
			lblHeader.setText("Delete Product");
			while (txtfSearch.isFocusOwner() == true)
			{
				txtfSearch.setText("");
			} 	
			lblSearch.setText("Enter Product ID");
			clearScreen();
			lblHeader.setVisible(true);
			showSearchScreen();
			btnIDSearch.setVisible(false);
			btnIDSearchDelete.setVisible(true);
		}
		if (e.getSource() == txtfSearch)
		{
			
			txtfSearch.setText("");
		}
		if (e.getSource() ==  btnIDSearch)
		{
			if (checkInt(txtfSearch.getText()) == true && productsList.containsKey(Integer.parseInt(txtfSearch.getText())))
			{
				clearScreen();
				showAddScreen();
				productSearch();
				btnEditProd.setVisible(true);
				btnAddProd.setVisible(false);
				pRight.setVisible(false);
			}
			else 
			{
				JOptionPane.showMessageDialog(null, "ERROR: Please enter a valid ID. Between 1000 and " +  (999 + productsList.size()));
			}
		}
		
		if (e.getSource() == btnIDSearchDelete)
		{
			
			if (checkInt(txtfSearch.getText()) == true && productsList.containsKey(Integer.parseInt(txtfSearch.getText())))
			{
				clearScreen();
				showDeleteScreen();
				productSearch();
				pRight.setVisible(false);
				btnResetProd.setEnabled(false);
				txtfProdName.setEnabled(false);
				txtfStockLevel.setEnabled(false);
				txtfProdPrice.setEnabled(false);
				cmbProdSize.setEnabled(false);
			}
			else 
			{
				JOptionPane.showMessageDialog(null, "ERROR: Please enter a valid ID. Between 1000 and " +  (999 + productsList.size()));
			}
		}
		if (e.getSource() == btnDeleteProd) 
		{
			int  tempId;
			int input = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this item from the system?", "Select an Option...",
						JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.ERROR_MESSAGE);
			if (input == 0)
			{
				tempId = productEdit.getProductID();
				productsList.remove(tempId);
				
				JOptionPane.showMessageDialog(null, "Item removed");
				displayByCat();
			}
			else if (input == 1 || input == 2)
			{
				clearScreen();
				showAddScreen();
			}
		}
		
		if (e.getSource() == mIDisplay)
		{
			clearScreen();
			pLeft.setVisible(true);
			taDisplay.setVisible(true);
			scroll.setVisible(true);
			
			Set set = productsList.entrySet();
			Iterator it = set.iterator();
			String s = "";
			sortProds = new String [productsList.size()];
			
			for (int i = 0; i < productsList.size(); i++) 
			{
				sortProds[i] = new String();
			}
		
			int sortCount = 0;
			while (it.hasNext())
			{
				Map.Entry mapEntry = (Map.Entry)it.next();
				sortProds[sortCount] = "" + productsList.get(mapEntry.getKey()).getProductID();
				 s += productsList.get(mapEntry.getKey()).toString("\n");
			}
			
			taDisplay.setText("");
			taDisplay.setText(displayHeadings);
			taDisplay.append(s);
		}
		if (e.getSource() == mIExit)
		{
			
			int input = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit the system?", "Exit System?",
						JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.ERROR_MESSAGE);
			if (input == 0)
			{
				writeProducts();
				writeSales();
				System.exit(0);
			}	
		}
		if (e.getSource() == cmbCat)
		{
			cmbItemName.removeAllItems();
			
			Set set = productsList.entrySet();
			Iterator it = set.iterator();

			while (it.hasNext())
			{
				Map.Entry mapEntry = (Map.Entry)it.next();
				
				Product p = new Product();
				p = (Product) mapEntry.getValue();
				
				if (p.getCategory().equals(cmbCat.getSelectedItem().toString()))
				{
					cmbItemName.addItem(p.getName());
				}
			}
		}
		if (e.getSource() == btnAddItem)
		{
			if (validateSaleItem() == true)
			{
				Set set = productsList.entrySet();
				Iterator it = set.iterator();

				while (it.hasNext())
				{
					Map.Entry mapEntry = (Map.Entry)it.next();
					Product p = new Product();
					p = (Product) mapEntry.getValue();

					if (cmbItemName.getSelectedItem().equals(productsList.get(mapEntry.getKey()).getName()))
					{
						itemCodes[basketCount] = (" " + p.getProductID());
						p = productsList.get(mapEntry.getKey());
						quantity = Integer.parseInt(txtfQuantity.getText());
						Double totalPrice = (quantity * p.getUnitPrice());

						String str = String.format("   %-9s %-20s %-9s %-11s %-9.2f", p.getProductID(), p.getName(), p.getUnitPrice(), quantity, totalPrice);
						taShowProducts.append("\n" + str);
						for (int i = 0; i < quantity; i++) 
						{
							basket[basketCount] = p;
							basketCount++;
						}
						saleTotal += totalPrice; //this is total basket cost //
					}
				}
				cmbCat.setSelectedIndex(0);
				txtfQuantity.setText("");
				txtfCustName.setEnabled(false);
				quantity = 0;
			}
			else
			{
				JOptionPane.showMessageDialog(null, errorMessage);
			}
		}
		if(e.getSource() == btnMakeSale)
		{
			String itemCodesTemp = "";
			
			for (int count = 0; count < basketCount; count++) 
			{
				if (itemCodes[count] != null)
				{
					itemCodesTemp += itemCodes[count];
				}
			}
			
			Sale s = new Sale();
			s.setSaleID(1000 + salesList.size());
			s.setCustomerName(txtfCustName.getText());
			s.setDateSold(LocalDate.now());
			s.setProductCodes(itemCodesTemp);
			s.setTotalPrice(saleTotal);
			
			salesList.add(s);
			refreshSale();
			
			for (int x = 0; x < basketCount; x++) // broken // -----------------------------------------------------------//
			{
				Product basketProd =  new Product();
				basketProd = productsList.get(basket[x].getProductID());
				basketProd.setStockLevel((basketProd.getStockLevel() -1));
				basketProd.setNoSold(basketProd.getNoSold()+1);
			}
			JOptionPane.showMessageDialog(null, "Sale Completed");
			basketCount = 0;
			quantity = 0;
			for (int i = 0; i < basket.length; i++) 
			{
				basket[i] = new Product();
			}
			Arrays.fill(itemCodes, null);
		}
		if (e.getSource() == mIAllSales)
		{
			taDisplay.setText("");
			String s = String.format("\t\t  ALL SALES AS OF " + currDate + " @ " + currTime);
			s += "\n----------------------------------------------------------";
			taDisplay.setText(s);
			clearScreen();
			pLeft.setVisible(true);
			taDisplay.setVisible(true);
			scroll.setVisible(true);
			String codesStr = "";
			
			
			for (int count = 0; count < salesList.size(); count++) 
			{
				taDisplay.append("\n");
				
				taDisplay.append("Sale ID: " + salesList.get(count).getSaleID() + "\n");
				taDisplay.append("Customer: " + salesList.get(count).getCustomerName() + "\n");
				taDisplay.append("Date: " + salesList.get(count).getDateSold() + "\n");
				//taDisplay.append("Item Codes: " + salesList.get(count).getProductCodes() + "\n");
				
				if (salesList.get(count).getProductCodes() != null || salesList.get(count).getProductCodes().contains(null) == false)
				{
					codesStr += codesStr + " ";
				}
				taDisplay.append("Item Codes: " + salesList.get(count).getProductCodes() + "\n");
				Double totalPrice = salesList.get(count).getTotalPrice();
				String strTotalPrice = String.format("%.2f", totalPrice);
				
				taDisplay.append("\n" + "Order Total: �" + strTotalPrice + "\n");
				taDisplay.append("----------------------------------------------------------");
				
				
			}
			
			btnSalesRep.setVisible(true);
			lblSpacer.setVisible(true);
			btnExitApp.setVisible(true);
		}
		if (e.getSource() == btnSalesRep)
		{
			try 
			{
				writeSalesReport();
			} 
			catch (FileNotFoundException e1) 
			{
				e1.printStackTrace();
			}
			JOptionPane.showMessageDialog(null, "Sales Report Generated");
		}
		
		if (e.getSource() == btnLowStockRep)
		{
			
		}
		if (e.getSource() == btnBeautyRep)
		{
			try 
			{
				writeBeautyReport();
			} 
			catch (FileNotFoundException e1) 
			{
				e1.printStackTrace();
			}
			JOptionPane.showMessageDialog(null, "Beauty Report Generated");
		}
		
		if (e.getSource() == btnFoodRep)
		{
			try 
			{
				writeFoodReport();
			} 
			catch (FileNotFoundException e1) 
			{
				e1.printStackTrace();
			}
			JOptionPane.showMessageDialog(null, "Food Report Generated");
		}
		if (e.getSource() == btnSportsRep)
		{
			try 
			{
				writeSportsReport();
			} 
			catch (FileNotFoundException e1) 
			{
				e1.printStackTrace();
			}
			JOptionPane.showMessageDialog(null, "Sports Nutrition Report Generated");
		}
		if (e.getSource() == btnVitaminsRep)
		{
			try 
			{
				writeVitaminsReport();
			} 
			catch (FileNotFoundException e1) 
			{
				e1.printStackTrace();
			}
			JOptionPane.showMessageDialog(null, "Vitamins Report Generated");
		}
		if (e.getSource() == btnWeightLossRep)
		{
			try 
			{
				writeWeightLossReport();
			} 
			catch (FileNotFoundException e1) 
			{
				e1.printStackTrace();
			}
			JOptionPane.showMessageDialog(null, "Weight Loss Report Generated");
		}

		if (e.getSource() == btnClearCart)
		{
			String s = String.format("   %-9s %-20s %-9s %-11s %-9s", "ItemID", "Item Desc.", "Price", "Quantity", "Total");
			s += "\n-------------------------------------------------------------";
			
			cmbCat.setSelectedIndex(0);
			txtfQuantity.setText("");
			txtfCustName.setText("");
			taShowProducts.setText(s);
			for (int i = 0; i < basket.length; i++) 
			{
				basket[i] = new Product();
			}
			//Arrays.fill(basket, null);
			txtfCustName.setEnabled(true);
		}
		if (e.getSource() == btnLowStockRep) 
		{
			try 
			{
				writeLowStockReport();
			} 
			catch (FileNotFoundException e1) 
			{
				e1.printStackTrace();
			}
			JOptionPane.showMessageDialog(null, "Low Stock Report Generated");
		}
	}
	private void displayByCat()
	{
		taDisplay.setText(displayHeadings);
		
		Set set = productsList.entrySet();
		Iterator it = set.iterator();
		
		int count = 1001;

			while (it.hasNext())
			{
				Map.Entry mapEntry = (Map.Entry)it.next();
				
				String s = productsList.get(mapEntry.getKey()).toString("\n");
				taDisplay.append(s);
			}
			
			count++;
		clearScreen();
		pLeft.setVisible(true);
		scroll.setVisible(true);
		taDisplay.setVisible(true);
	}
	private void displayLowStock()
	{
		taDisplay.setText("");
		taDisplay.append(displayHeadings);
		Set set = productsList.entrySet();
		
		Iterator it = set.iterator();
		
		while (it.hasNext())
		{
			Map.Entry mapEntry = (Map.Entry)it.next();
			if (productsList.get(mapEntry.getKey()).getStockLevel() <= 10)
			{
				String print = productsList.get(mapEntry.getKey()).toString("\n");
				taDisplay.append(print);
			}
		}
	}
	private boolean validateProduct()
	{
		errorMessage = "                       ERROR - INVALID INPUT \n"
				  + "--------------------------------------------------------------------------------\n";;
						
		
		boolean result = true;
		if (txtfProdName.getText().isBlank() == true || txtfProdName.getText().trim().length() < 4 || txtfProdName.getText().trim().length() >20)
		{
			errorMessage += "Please Enter a Valid Product Name (Between 4-20 characters)\n";
			result = false;
		}
		if (cmbProdSize.getSelectedIndex() == 0)
		{
			errorMessage += "Please Select a Product Size\n";
			result = false;
		}
		if (checkDouble(txtfProdPrice.getText()) == false || txtfProdPrice.getText().isBlank())
			{
				errorMessage += "Please Enter a Valid Price\n";
				result = false;
			}
		if (checkInt(txtfStockLevel.getText()) == false || txtfStockLevel.getText().isBlank())
		{
			errorMessage += "Please Enter a Valid No. of Stock\n";
			result = false;
		}
		return result;
	}
	private boolean validateSaleItem()
	{
			errorMessage = "                       ERROR - INVALID INPUT \n"
					  + "--------------------------------------------------------------------------------\n";;
					
			
			boolean result = true;
			if (cmbCat.getSelectedIndex() == 0)
			{
				errorMessage += "Please choose a product from the dropdown list\n";
				result = false;
			}
			if (checkInt(txtfQuantity.getText().trim()) == false)
			{
				errorMessage += "Please enter a valid quantity\n";
				txtfQuantity.setText("");
				result = false;
			}
			if (Integer.parseInt(txtfQuantity.getText()) > 50)
			{
				errorMessage += "Max basket quantity is 50\n";
				txtfQuantity.setText("");
				result = false;
			}
			if (txtfCustName.getText().trim().isEmpty() || txtfCustName.getText().length() < 4 || txtfCustName.getText().length() > 15 || txtfCustName.getText().matches("^[a-zA-Z]*+$") == false)
			{
				errorMessage += "Please enter a valid name\n";
				txtfCustName.setText("");
				result = false;
			}
			return result;
	}
	
	private void showSearchScreen()
	{
		pLeft.setVisible(true);
		pRight.setVisible(false);
		
		lblSearch.setVisible(true);
		txtfSearch.setVisible(true);
		btnIDSearch.setVisible(true);
	}
	private void clearInput()
	{
		txtfProdName.setText("");
		txtfProdPrice.setText("");
		cmbProdSize.setSelectedIndex(0);
		txtfSearch.setText("");
		txtfStockLevel.setText("");
	}
	private void showAddScreen() 
	{
		clearScreen();
		pLeft.setVisible(true);
		pRight.setVisible(true);
		
		lblAddTitle.setVisible(true);
		lblProdID.setVisible(true);
		lblProdIDShow.setVisible(true);
		lblProdName.setVisible(true);
		lblProdSize.setVisible(true);
		lblProdCat.setVisible(true);
		lblPrice.setVisible(true);
		lblStockLevel.setVisible(true);
		
		txtfProdName.setVisible(true);
		txtfProdPrice.setVisible(true);
		cmbProdSize.setVisible(true);
		lblProdCatShow.setVisible(true);
		txtfStockLevel.setVisible(true);
		
		btnAddProd.setVisible(true); 		
		btnResetProd.setVisible(true);	 		
		btnCancelProd.setVisible(true);	
		btnExitApp.setVisible(true);
	}
	private void showDeleteScreen()
	{
		clearScreen();
		pLeft.setVisible(true);
		pRight.setVisible(true);
		
		lblAddTitle.setVisible(true);
		lblProdID.setVisible(true);
		lblProdIDShow.setVisible(true);
		lblProdName.setVisible(true);
		lblProdSize.setVisible(true);
		lblProdCat.setVisible(true);
		lblPrice.setVisible(true);
		lblStockLevel.setVisible(true);
		
		txtfProdName.setVisible(true);
		txtfProdPrice.setVisible(true);
		cmbProdSize.setVisible(true);
		lblProdCatShow.setVisible(true);
		txtfStockLevel.setVisible(true);
		
		btnEditProd.setVisible(false);
		btnDeleteProd.setVisible(true);		
		btnResetProd.setVisible(true);	 		
		btnCancelProd.setVisible(true);	
		btnExitApp.setVisible(true);
	}
	private void showAddBeauty()
	{
		lblAddTitle.setText("Add Beauty Item");
		lblProdIDShow.setText("" + (1000 + productsList.size()));
		showAddScreen();
		lblProdCatShow.setText("Beauty");
		
		prodDisplayScroll.setVisible(true);
		taShowProducts.setVisible(true);
		
	}
	private void showAddFood()
	{
		lblAddTitle.setText("Add Food Item");
		lblProdIDShow.setText("" + (1000 + productsList.size()));
		showAddScreen();
		lblProdCatShow.setText("Food");
		
		prodDisplayScroll.setVisible(true);
		taShowProducts.setVisible(true);
	}
	private void showAddSportsNutrition()
	{
		lblAddTitle.setText("Add Sports Nutr. Item");
		lblProdIDShow.setText("" + (1000 + productsList.size()));
		showAddScreen();
		lblProdCatShow.setText("Sports Nutrition");
		
		prodDisplayScroll.setVisible(true);
		taShowProducts.setVisible(true);
	}
	private void showAddVitamin()
	{
		lblAddTitle.setText("Add Vitamins Item");
		lblProdIDShow.setText("" + (1000 + productsList.size()));
		showAddScreen();
		lblProdCatShow.setText("Vitamins");
		
		prodDisplayScroll.setVisible(true);
		taShowProducts.setVisible(true);
	}
	private void showAddWeightLoss()
	{
		lblAddTitle.setText("Add Weight Loss Item");
		lblProdIDShow.setText("" + (1000 + productsList.size()));
		showAddScreen();
		lblProdCatShow.setText("Weight Loss");
		
		prodDisplayScroll.setVisible(true);
		taShowProducts.setVisible(true);
	}
	private void addComponents()
	{
		
		//Product Screen //
		
		addComp(pLeft						,1,1,5,1,1,1);
		addComp(pRight						,6,1,5,1,5,1);
		
		addComp(pLeft, lblAddTitle	 		,1,0,1,1,1,1);
		addComp(pLeft, lblProdID	 		,1,1,1,1,1,1);
		addComp(pLeft, lblProdName	 		,1,2,1,1,1,1);
		addComp(pLeft, lblProdCat	 		,1,3,1,1,1,1);
		addComp(pLeft, lblProdSize		 	,1,4,1,1,1,1);
		addComp(pLeft, lblPrice	 			,1,5,1,1,1,1);
		addComp(pLeft, lblStockLevel	 	,1,6,1,1,1,1);
		
		
		addComp(pLeft, lblProdIDShow	 	,2,1,2,1,1,1);
		addComp(pLeft, txtfProdName	 		,2,2,2,1,1,1);
		addComp(pLeft, lblProdCatShow 		,2,3,2,1,1,1);
		addComp(pLeft, cmbProdSize			,2,4,2,1,1,1);
		addComp(pLeft, txtfProdPrice	 	,2,5,2,1,1,1);
		addComp(pLeft, txtfStockLevel	 	,2,6,2,1,1,1);
		
		addComp(pLeft, btnAddProd	 		,1,7,1,1,1,1);
		addComp(pLeft, btnEditProd	 		,1,7,1,1,1,1);
		addComp(pLeft, btnDeleteProd	 	,1,7,1,1,1,1);
		
		addComp(pLeft, btnResetProd	 		,2,7,1,1,1,1);
		addComp(pLeft, btnCancelProd	 	,1,8,1,1,1,1);
		addComp(pLeft, btnExitApp			,2,8,1,1,1,1);

		addComp(pLeft, lblHeader	 		,2,1,1,1,0,0);
		addComp(pLeft, btnBeauty	 		,2,2,1,1,0,1);
		addComp(pLeft, btnFood	 			,2,3,1,1,0,1);
		addComp(pLeft, btnSportsNutrition	,2,4,1,1,0,1);
		addComp(pLeft, btnVitamins	    	,2,5,1,1,0,1);
		addComp(pLeft, btnWeightloss 		,2,6,1,1,0,1);
		
		addComp(pLeft,  scroll 				,1,1,5,5,2,7);
		addComp(pRight, prodDisplayScroll	,1,1,5,5,2,7);
		
		
		addComp(pLeft, 	lblSearch			,2,5,1,1,0,0);
		addComp(pLeft, 	txtfSearch	 		,2,6,1,1,0,0);
		addComp(pLeft, 	btnIDSearch			,2,9,1,1,0,0);
		addComp(pLeft, 	btnIDSearchDelete	,2,9,1,1,0,0);
		
		// Make Sale Screen //

		addComp(pLeft, 	btnAddItem			,1,7,1,1,0,1);
		addComp(pLeft, 	btnMakeSale			,2,7,1,1,1,1);
		addComp(pLeft, 	btnCancelSale		,1,8,1,1,1,1);
		addComp(pLeft, 	btnClearCart		,2,8,1,1,1,1);
		
		addComp(pLeft,  cmbCat				,1,3,1,1,1,1);
		addComp(pLeft,  cmbItemName			,2,3,1,1,1,1);
		addComp(pLeft,  lblQuantity			,1,4,1,1,1,1);
		addComp(pLeft,  txtfQuantity		,2,4,1,1,1,1);
		addComp(pLeft,  lblSaleDate			,1,5,1,1,1,1);
		addComp(pLeft,  lblSaleDateShow		,2,5,1,1,1,1);
		addComp(pLeft,  lblCustName			,1,6,1,1,1,1);
		addComp(pLeft,  txtfCustName		,2,6,1,1,1,1);
		
		addComp(pLeft,  lblSaleID			,1,2,1,1,1,1);
		addComp(pLeft,  lblSaleIDShow		,2,2,1,1,1,1);
		
		addComp(pLeft, 	lblSpacer			,2,7,1,1,1,1);
		addComp(pLeft,  btnSalesRep			,3,8,1,1,1,1);
		addComp(pLeft,  btnLowStockRep		,3,8,1,1,1,1);
		
		addComp(pLeft,  btnBeautyRep		,1,7,1,1,1,0);
		addComp(pLeft,  btnFoodRep			,2,7,1,1,1,0);
		addComp(pLeft,  btnSportsRep		,3,7,1,1,1,0);
		addComp(pLeft,  btnVitaminsRep		,4,7,1,1,1,0);
		addComp(pLeft,  btnWeightLossRep	,5,7,1,1,1,0);
		

	}
	private void showSaleScreen()
	{
		clearScreen();
		pRight.setVisible(true);
		pLeft.setVisible(true);
		taDisplay.setVisible(false);
		taShowProducts.setVisible(true);
		
		lblHeader.setVisible(false);
		
		btnAddItem.setVisible(true);
		btnMakeSale.setVisible(true);	
		btnClearCart.setVisible(true);
		btnCancelProd.setVisible(true);
		
		cmbCat.setVisible(true);
		cmbItemName.setVisible(true);
		
		lblQuantity.setVisible(true);
		txtfQuantity.setVisible(true);
		txtfCustName.setVisible(true);
		lblCustName.setVisible(true);
		lblSaleDate.setVisible(true);
		lblSaleDateShow.setVisible(true);
		lblSaleID.setVisible(true);
		lblSaleIDShow.setVisible(true);
		
	}
	private void clearScreen()
	{
		lblSpacer.setVisible(false);
		pLeft.setVisible(false);
		pRight.setVisible(false);
		btnBeauty.setVisible(false);
		btnFood.setVisible(false);
		btnSportsNutrition.setVisible(false);
		btnVitamins.setVisible(false);
		btnWeightloss.setVisible(false);
		
		btnAddProd.setVisible(false);
		btnResetProd.setVisible(false);
		btnCancelProd.setVisible(false);
		btnEditProd.setVisible(false);
		btnExitApp.setVisible(false);
		
		btnSalesRep.setVisible(false);
		btnLowStockRep.setVisible(false);
		btnBeautyRep.setVisible(false);
		btnFoodRep.setVisible(false);
		btnSportsRep.setVisible(false);
		btnVitaminsRep.setVisible(false);
		btnWeightLossRep.setVisible(false);
		
		lblAddTitle.setVisible(false);
		lblProdID.setVisible(false);
		lblProdIDShow.setVisible(false);
		lblProdName.setVisible(false);
		lblProdSize.setVisible(false);
		lblProdCat.setVisible(false);
		lblPrice.setVisible(false);
		txtfProdName.setVisible(false);
		txtfProdPrice.setVisible(false);
		txtfStockLevel.setVisible(false);
		
		cmbProdSize.setVisible(false);
		lblProdCat.setVisible(false);
		lblProdCatShow.setVisible(false);
		lblStockLevel.setVisible(false);
		scroll.setVisible(false);
		
		lblSearch.setVisible(false);
		txtfSearch.setVisible(false);
		btnIDSearch.setVisible(false);
		btnDeleteProd.setVisible(false);
		btnIDSearchDelete.setVisible(false);
		
		btnAddItem.setVisible(false);
		btnMakeSale.setVisible(false);	
		btnClearCart.setVisible(false);
		btnCancelSale.setVisible(false);
		cmbCat.setVisible(false);
		cmbItemName.setVisible(false);
		taDisplay.setVisible(false);
		taShowProducts.setVisible(false);
		
		lblQuantity.setVisible(false);
		txtfQuantity.setVisible(false);
		
		lblSaleDate.setVisible(false);
		lblCustName.setVisible(false);
		lblSaleDateShow.setVisible(false);
		txtfCustName.setVisible(false);
		
		lblSaleID.setVisible(false);
		lblSaleIDShow.setVisible(false);
		
		lblHeader.setVisible(false);
		
	}
	private void showAddOptions()
	{
		lblHeader.setVisible(true);
		pLeft.setVisible(true);
		btnBeauty.setVisible(true);
		btnFood.setVisible(true);
		btnSportsNutrition.setVisible(true);
		btnVitamins.setVisible(true);
		btnWeightloss.setVisible(true);
		
	}
	private void displayBeautyItems()
	{
		taShowProducts.append(displayHeadings);
		Set set = productsList.entrySet();
		
		Iterator it = set.iterator();
		
		while (it.hasNext())
		{
			Map.Entry mapEntry = (Map.Entry)it.next();
			if (productsList.get(mapEntry.getKey()).getCategory().equals("Beauty"))
			{
				String print = productsList.get(mapEntry.getKey()).toString("\n");
				taShowProducts.append("\n" + print);
			}
		}
	}
	private void displayFoodItems()
	{
		taShowProducts.append(displayHeadings);
		Set set = productsList.entrySet();
		
		Iterator it = set.iterator();
		
		while (it.hasNext())
		{
			Map.Entry mapEntry = (Map.Entry)it.next();
			if (productsList.get(mapEntry.getKey()).getCategory().equals("Food"))
			{
				String print = productsList.get(mapEntry.getKey()).toString("\n");
				taShowProducts.append("\n" + print);
			}
		}
	}
	private void displaySportsItems()
	{
		taShowProducts.append(displayHeadings);
		Set set = productsList.entrySet();
		
		Iterator it = set.iterator();
		
		while (it.hasNext())
		{
			Map.Entry mapEntry = (Map.Entry)it.next();
			if (productsList.get(mapEntry.getKey()).getCategory().equals("Sports Nutrition"))
			{
				String print = productsList.get(mapEntry.getKey()).toString("\n");
				taShowProducts.append("\n" + print);
			}
		}
	}	
	private void displayVitaminsItems()
	{
		taShowProducts.append(displayHeadings);
		Set set = productsList.entrySet();
		
		Iterator it = set.iterator();
		
		while (it.hasNext())
		{
			Map.Entry mapEntry = (Map.Entry)it.next();
			if (productsList.get(mapEntry.getKey()).getCategory().equals("Vitamins"))
			{
				String print = productsList.get(mapEntry.getKey()).toString("\n");
				taShowProducts.append("\n" + print);
			}
		}
	}	
	private void displayWeightLossItems()
	{
		taShowProducts.append(displayHeadings);
		Set set = productsList.entrySet();
		
		Iterator it = set.iterator();
		
		while (it.hasNext())
		{
			Map.Entry mapEntry = (Map.Entry)it.next();
			if (productsList.get(mapEntry.getKey()).getCategory().equals("Weight Loss"))
			{
				String print = productsList.get(mapEntry.getKey()).toString("\n");
				taShowProducts.append("\n" + print);
			}
		}
	}
	private void productSearch() 
	{
		String StringSearchID = "";
		StringSearchID = txtfSearch.getText();
		
		int searchID = 0;
		searchID = Integer.parseInt(txtfSearch.getText());
		productEdit = productsList.get(searchID);
		boolean result = false;
		
			if (productsList.containsKey(searchID))
			{
				
				String tempID = Integer.toString(productEdit.getProductID());
				String tempPrice = Double.toString(productEdit.getUnitPrice());
				String tempStock = Integer.toString(productEdit.getStockLevel());

				lblProdIDShow.setText(tempID);
				txtfProdName.setText(productEdit.getName().toString());
				lblProdCatShow.setText(productEdit.getCategory().toString());
				cmbProdSize.setSelectedItem(productEdit.getSize().toString());
				txtfProdPrice.setText((tempPrice).toString());	
				txtfStockLevel.setText(tempStock);
			}
			else
			{
				clearScreen();
				showSearchScreen();
				pRight.setVisible(false);
				txtfSearch.setText("");
				JOptionPane.showMessageDialog(null, "ERROR: This ID does not exist");
				btnEditProd.setVisible(false);
			}
	}	 
	public void assignActionListeners()
	{
		// Menus //
		menuProducts.addActionListener(this);
		menuStock.addActionListener(this);
		menuReports.addActionListener(this);
		menuSystem.addActionListener(this);
				
		// Menu Items //
		mIAdd.addActionListener(this);
		mIUpdate.addActionListener(this);
		mIDelete.addActionListener(this);
		mIDisplay.addActionListener(this);
		mIMakeSale.addActionListener(this);
		mILowStock.addActionListener(this);
		mIProductsByCat.addActionListener(this);
		mIAllSales.addActionListener(this);
		mIExit.addActionListener(this);
		btnBeauty .addActionListener(this);                    
		btnFood.addActionListener(this);
		
		btnSportsNutrition.addActionListener(this);
		btnVitamins.addActionListener(this);
		btnWeightloss.addActionListener(this);
		
		btnAddProd.addActionListener(this);
		btnResetProd.addActionListener(this);
		btnCancelProd.addActionListener(this);
		btnIDSearch.addActionListener(this);
		btnExitApp.addActionListener(this);
		btnEditProd.addActionListener(this);
		btnDeleteProd.addActionListener(this);
		btnIDSearchDelete.addActionListener(this);
		btnCancelSale.addActionListener(this);
		
		btnAddItem.addActionListener(this);
		btnMakeSale.addActionListener(this);
		
		btnSalesRep.addActionListener(this);
		btnLowStockRep.addActionListener(this);
		btnBeautyRep.addActionListener(this);
		btnFoodRep.addActionListener(this);
		btnSportsRep.addActionListener(this);
		btnVitaminsRep.addActionListener(this);
		btnWeightLossRep.addActionListener(this);
		
		cmbCat.addActionListener(this);
		btnClearCart.addActionListener(this);
		
	}
	public boolean checkInt(String text)
	{
		try 
		{
			Integer.parseInt(text);
			return true;
		} catch (NumberFormatException e) 
		{
		 return false;
		} 
	}
	public boolean checkDouble(String text)
	{
		try 
		{
			Double.parseDouble(text);
			return true;
		} catch (NumberFormatException e) 
		{
		 return false;
		} 
	}
	private void handleFrmExitButton()
	{
		// Handles the exit button on form //
		// Asks user if they are sure they want to close the programme -  can't get it working properly //
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
		    
		    public void windowClosing(WindowEvent we)
		    { 
		        String ObjButtons[] = {"Yes","No"};
		        int PromptResult = JOptionPane.showOptionDialog(null,"Are you sure you want to exit?","One World Health",JOptionPane.DEFAULT_OPTION,JOptionPane.WARNING_MESSAGE,null,ObjButtons,ObjButtons[1]);
		        if(PromptResult==JOptionPane.YES_OPTION)
		        {
					writeProducts();
					writeSales();
					System.exit(0);
		        }
		    }
		});
	}
	private boolean validateSameName()
	{
		boolean result = false;
		
		int prodCount = productsList.size();
		
		String[] prodNames = new String [prodCount];
		
		Set set = productsList.entrySet();
		Iterator it = set.iterator();
		
		int arrayCount = 0;		
		
		while (it.hasNext())
		{
			Map.Entry mapEntry = (Map.Entry)it.next();
			
			prodNames[arrayCount] = productsList.get(mapEntry.getKey()).getName();
			arrayCount++;
			
		}

		for (int count = 0; count < prodNames.length; count++) 
		{
			if (txtfProdName.getText().compareTo((prodNames[count])) == 0)
			{
				result = true;
				txtfProdName.setText("");
			}
		}
		return result;
	}
	private void writeProducts()
	{
		try 
		{
			FileOutputStream fos = new FileOutputStream(productsFile);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(productsList);
			oos.close();
			fos.close();	
		} 
		catch (FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, " Products File Not Found");
		}
		catch (IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not write to Products file");
		}
	}
	private void readProducts()
	{
		try 
		{
			FileInputStream fis = new FileInputStream(productsFile);
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			productsList = (HashMap <Integer, Product> ) ois.readObject();
			ois.close();
			fis.close();
		} 
		catch (ClassNotFoundException cEx)
		{
			JOptionPane.showMessageDialog(null, "The contents could not be read");
		}
		catch (FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "Products File Not Found");
		}
		catch (IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not write to file");
		}
	}
	private void writeSales()
	{
		try 
		{
			FileOutputStream fos = new FileOutputStream(salesFile);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(salesList);
			oos.close();
			fos.close();
		} 
		catch (FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, " Sales File Not Found");
		}
		catch (IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not write to Sales file");
		}
	}
	private void readSales()
	{
		try 
		{
			FileInputStream fis = new FileInputStream(salesFile);
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			salesList = (LinkedList <Sale>) ois.readObject();
			ois.close();
			fis.close();
		} 
		catch (ClassNotFoundException cEx)
		{
			JOptionPane.showMessageDialog(null, "The contents could not be read");
		}
		catch (FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "Sales File Not Found");
		}
		catch (IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not write to Sales file");
		}
	}
	private void writeSalesReport() throws FileNotFoundException
	{
		PrintWriter salesReportWrite = new PrintWriter(new File("salesReport - " + LocalDate.now().toString() + ".txt"));
		
		salesReportWrite.println("\t\t\t\tSALES PRODUCTS REPORT");
		salesReportWrite.println("\t\t\t  ALL SALES MADE AS OF " + timeStamp);
		salesReportWrite.println("------------------------------------------------------------------------------------------");

		for (int count = 0; count < salesList.size(); count++) 
		{	
			salesReportWrite.println("\nSale ID: " + salesList.get(count).getSaleID() + "\n");
			salesReportWrite.println("Customer: " + salesList.get(count).getCustomerName() + "\n");
			salesReportWrite.println("Date: " + salesList.get(count).getDateSold() + "\n");
			salesReportWrite.println("Item Codes: " + salesList.get(count).getProductCodes() + "\n");
			salesReportWrite.println("Order Total: �" + salesList.get(count).getTotalPrice());
				
			salesReportWrite.println("-----------------------------------------------------------------------------------------");
		}
			
		salesReportWrite.println("-----------------------------------------------------------------------------------------");	
		salesReportWrite.println("--------------------------------------END OF REPORT--------------------------------------");
		salesReportWrite.println("-----------------------------------------------------------------------------------------");
		salesReportWrite.close();
	}	
	private void writeBeautyReport() throws FileNotFoundException
	{
		PrintWriter prodReportWrite = new PrintWriter(new File("beautyReport - " + LocalDate.now().toString() + ".txt"));
		prodReportWrite.println("\t\t\t\tBEAUTY PRODUCTS REPORT");
		prodReportWrite.println("\t\t\t   REPORT CREATED ON " + timeStamp);
		prodReportWrite.println(" ------------------------------------------------------------------------------------------");
		prodReportWrite.println(displayHeadings);
		
		Set set = productsList.entrySet();
		Iterator it = set.iterator();

		while (it.hasNext())
		{
			Map.Entry mapEntry = (Map.Entry)it.next();
			
			if (productsList.get(mapEntry.getKey()).getCategory().equals("Beauty"))
			{
				prodReportWrite.println(productsList.get(mapEntry.getKey()).toString("\n"));
			}	
		}
		prodReportWrite.println("\n -----------------------------------------------------------------------------------------");	
		prodReportWrite.println(" --------------------------------------END OF REPORT--------------------------------------");
		prodReportWrite.println(" -----------------------------------------------------------------------------------------");
		prodReportWrite.close();
	}
	private void writeFoodReport() throws FileNotFoundException
	{
		PrintWriter prodReportWrite = new PrintWriter(new File("foodReport - " + LocalDate.now().toString() + ".txt"));
		prodReportWrite.println("\t\t\t\tFOOD PRODUCTS REPORT");
		prodReportWrite.println("\t\t\t   REPORT CREATED ON " + timeStamp);
		prodReportWrite.println(" ------------------------------------------------------------------------------------------");
		prodReportWrite.println(displayHeadings);
		
		Set set = productsList.entrySet();
		Iterator it = set.iterator();

		while (it.hasNext())
		{
			Map.Entry mapEntry = (Map.Entry)it.next();
			
			if (productsList.get(mapEntry.getKey()).getCategory().equals("Food"))
			{
				prodReportWrite.println(productsList.get(mapEntry.getKey()).toString("\n"));
			}	
		}
		prodReportWrite.println("\n -----------------------------------------------------------------------------------------");	
		prodReportWrite.println(" --------------------------------------END OF REPORT--------------------------------------");
		prodReportWrite.println(" -----------------------------------------------------------------------------------------");
		prodReportWrite.close();
	}
	private void writeSportsReport() throws FileNotFoundException
	{
		PrintWriter prodReportWrite = new PrintWriter(new File("sportsReport - " + LocalDate.now().toString() + ".txt"));
		prodReportWrite.println("\t\t\t     SPORTS NUTRITION PRODUCTS REPORT");
		prodReportWrite.println("\t\t\t   REPORT CREATED ON " + timeStamp);
		prodReportWrite.println(" ------------------------------------------------------------------------------------------");
		prodReportWrite.println(displayHeadings);
		
		Set set = productsList.entrySet();
		Iterator it = set.iterator();

		while (it.hasNext())
		{
			Map.Entry mapEntry = (Map.Entry)it.next();
			
			if (productsList.get(mapEntry.getKey()).getCategory().equals("Sports Nutrition"))
			{
				prodReportWrite.println(productsList.get(mapEntry.getKey()).toString("\n"));
			}	
		}
		prodReportWrite.println("\n -----------------------------------------------------------------------------------------");	
		prodReportWrite.println(" --------------------------------------END OF REPORT--------------------------------------");
		prodReportWrite.println(" -----------------------------------------------------------------------------------------");
		prodReportWrite.close();
	}
	private void writeVitaminsReport() throws FileNotFoundException
	{
		PrintWriter prodReportWrite = new PrintWriter(new File("vitaminsReport - " + LocalDate.now().toString() + ".txt"));
		prodReportWrite.println("\t\t\t\t  VITAMIN PRODUCTS REPORT");
		prodReportWrite.println("\t\t\t   REPORT CREATED ON " + timeStamp);
		prodReportWrite.println(" ------------------------------------------------------------------------------------------");
		prodReportWrite.println(displayHeadings);
		
		Set set = productsList.entrySet();
		Iterator it = set.iterator();

		while (it.hasNext())
		{
			Map.Entry mapEntry = (Map.Entry)it.next();
			
			if (productsList.get(mapEntry.getKey()).getCategory().equals("Vitamins"))
			{
				prodReportWrite.println(productsList.get(mapEntry.getKey()).toString("\n"));
			}	
		}
		prodReportWrite.println("\n -----------------------------------------------------------------------------------------");	
		prodReportWrite.println(" --------------------------------------END OF REPORT--------------------------------------");
		prodReportWrite.println(" -----------------------------------------------------------------------------------------");
		prodReportWrite.close();
	}
	private void writeWeightLossReport() throws FileNotFoundException
	{
		PrintWriter prodReportWrite = new PrintWriter(new File("weightLossReport - " + LocalDate.now().toString() + ".txt"));
		prodReportWrite.println("\t\t\t\tWEIGHT LOSS PRODUCTS REPORT");
		prodReportWrite.println("\t\t\t   REPORT CREATED ON " + timeStamp);
		prodReportWrite.println(" ------------------------------------------------------------------------------------------");
		prodReportWrite.println(displayHeadings);
		
		Set set = productsList.entrySet();
		Iterator it = set.iterator();

		while (it.hasNext())
		{
			Map.Entry mapEntry = (Map.Entry)it.next();
			
			if (productsList.get(mapEntry.getKey()).getCategory().equals("Weight Loss"))
			{
				prodReportWrite.println(productsList.get(mapEntry.getKey()).toString("\n"));
			}	
		}
			
		prodReportWrite.println("\n -----------------------------------------------------------------------------------------");	
		prodReportWrite.println(" --------------------------------------END OF REPORT--------------------------------------");
		prodReportWrite.println(" -----------------------------------------------------------------------------------------");
		prodReportWrite.close();
	}
	private void writeLowStockReport() throws FileNotFoundException
	{
			PrintWriter lowStockReportWrite = new PrintWriter(new File("LowStockReport - " + LocalDate.now().toString() + ".txt"));
			lowStockReportWrite.println("\t\t\t\tLOW STOCK PRODUCTS REPORT");
			lowStockReportWrite.println("\t\t\t   REPORT CREATED ON " + timeStamp);
			lowStockReportWrite.println(" ------------------------------------------------------------------------------------------");
			lowStockReportWrite.println(displayHeadings);
			
			Set set = productsList.entrySet();
			Iterator it = set.iterator();

			while (it.hasNext())
			{
				Map.Entry mapEntry = (Map.Entry)it.next();
				
				if (productsList.get(mapEntry.getKey()).getStockLevel() <= 10)
				{
					lowStockReportWrite.println(productsList.get(mapEntry.getKey()).toString("\n"));
				}	
			}
			
			lowStockReportWrite.println("\n -----------------------------------------------------------------------------------------");	
			lowStockReportWrite.println(" --------------------------------------END OF REPORT--------------------------------------");
			lowStockReportWrite.println(" -----------------------------------------------------------------------------------------");
			lowStockReportWrite.close();
		}	
	private void refreshSale()
	{
		String s = String.format("   %-9s %-20s %-9s %-11s %-9s", "ItemID", "Item Desc.", "Price", "Quantity", "Total");
		s += "\n----------------------------------------------------------------";
		
		cmbCat.setSelectedIndex(0);
		txtfQuantity.setText("");
		txtfCustName.setText("");
		txtfCustName.setEnabled(true);
		taShowProducts.setText(s);
		
		clearScreen();
		showSaleScreen();	
		
		taShowProducts.setText(s);
		LocalDate saleDate = LocalDate.now();
		lblSaleDateShow.setText(saleDate.toString());
		
		lblSaleIDShow.setText("" + (1000 + salesList.size()));
	}

}

