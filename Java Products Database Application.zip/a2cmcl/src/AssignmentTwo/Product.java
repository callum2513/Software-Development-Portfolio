package AssignmentTwo;

public class Product implements java.io.Serializable
{
	private int productID;
	private String name, size, category;
	private int noSold = 0, stockLevel = 0;
	private double unitPrice;
//	public static int beautyCount = 1000, foodCount = 2000, sportsCount = 3000, vitaminsCount = 4000, weightLossCount = 5000;
	
	
	public Product()
	{
		this.productID = 1000;
		this.name = "";
		this.size = "";
		this.category = "";
		this.noSold = 0;
		this.stockLevel = 0;
		this.unitPrice = 0.0;
	}
	
	public Product(int productID, String name, String category,String size, double unitPrice, int stockLevel, int noSold)
	{

		this.productID = productID;
		this.name = name;
		this.size = size;
		this.category = category;
		this.noSold = noSold;
		this.stockLevel = stockLevel;
		this.unitPrice = unitPrice;
	}
	
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getNoSold() {
		return noSold;
	}
	public void setNoSold(int noSold) {
		this.noSold = noSold;
	}
	public int getStockLevel() {
		return stockLevel;
	}
	public void setStockLevel(int stockLevel) {
		this.stockLevel = stockLevel;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	public String toString(String s)
	{
		
		s += String.format("  %-8d %-20s %-8s %-18s %11.2f %7d %7d", productID, name, size, category, unitPrice, stockLevel, noSold);
		return s;
	}
}
