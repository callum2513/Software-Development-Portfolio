package AssignmentTwo;

import java.time.LocalDate;

public class Sale implements java.io.Serializable
{
	int saleID;
	String customerName;
	LocalDate dateSold;
	double totalPrice;
	String productCodes; 
	
	public static int idSaleCount = 10000;
	
	public Sale()
	{
		this.saleID = 10000;
		this.customerName = "";
		this.dateSold = LocalDate.now();
		this.totalPrice = 0.0;
		this.productCodes = "";
	}
	
	public Sale(int saleID, String customerName, LocalDate dateSold, double totalPrice, String productCodes)
	{
		idSaleCount++;
		saleID = idSaleCount;
		
		this.saleID = saleID;
		this.customerName = customerName;
		this.dateSold = dateSold;
		this.totalPrice = totalPrice;
		this.productCodes = productCodes;
	}
	
	public int getSaleID() {
		return saleID;
	}
	public void setSaleID(int saleID) {
		this.saleID = saleID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public LocalDate getDateSold() {
		return dateSold;
	}
	public void setDateSold(LocalDate dateSold) {
		this.dateSold = dateSold;
	}
	public double getTotalPrice() 
	{
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getProductCodes() {
		return productCodes;
	}
	public void setProductCodes(String productCodes) {
		this.productCodes = productCodes;
	}
	
	public String toString(String s)
	{
		s += String.format("   %-9d %-20s %-9s  %-9s %-11.3f", saleID, customerName, dateSold, productCodes, totalPrice);
		return s;
		
	
	}
	
}
