package AssignmentTwo;

public class MyException extends Exception
{
	private String message;
	
	
	MyException (String s)
	{
		message = s;
	}
	
	MyException ()
	{
		message = "Invalid Data";
	}
	
	public String toString()
	{
		return "ERROR: " + message;
	}
}
